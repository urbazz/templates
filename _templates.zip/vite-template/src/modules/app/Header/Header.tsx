import React from 'react'

export const Header = () => {
  return (
    <header className="header">

    </header>
  )
}