import React from 'react'

interface Props {}

function Container(children) {
    return (
        <div className="container">
            {children}
        </div>
    )
}

export default Container
