// import swichHeroBg from "./modules/_hero";
// import Menu from "./plugins/menu";
// import openMenu from "./functions/openMenu";

window.addEventListener('DOMContentLoaded', ()=> {


})
